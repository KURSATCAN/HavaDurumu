﻿angular.module('starter.controllers', [])

.controller('AppCtrl', function($scope, $ionicModal, $timeout) {

 
})


.controller('HavaDurumuCtrl', function ($scope, $http, $filter, $ionicPopup, $window) {

    $scope.listemodel = [];
    $scope.listedata = [
        { id: "Adana", label: "Adana" },
        { id: "Adiyaman", label: "Adiyaman" },
        { id: "Afyonkarahisar", label: "Afyonkarahisar" },
        { id: "Agri", label: "Agri" },
        { id: "Amasya", label: "Amasya" },
        { id: "Ankara", label: "Ankara" },
        { id: "Antalya", label: "Antalya" },
        { id: "Artvin", label: "Artvin" },
        { id: "Aydin", label: "Aydin" },
        { id: "Bilecik", label: "Bilecik" },
        { id: "Bingol", label: "Bingol" },
        { id: "Bitlis", label: "Bitlis" },
        { id: "Bolu", label: "Bolu" },
        { id: "Burdur", label: "Burdur" },
        { id: "Bursa", label: "Bursa" },
        { id: "Canakkale", label: "Canakkale" },
        { id: "Cankiri", label: "Cankiri" },
        { id: "Corum", label: "Corum" },
        { id: "Denizli", label: "Denizli" },
        { id: "Diyarbakir", label: "Diyarbakir" },
        { id: "Edirne", label: "Edirne" },
        { id: "Elazig", label: "Elazig" },
        { id: "Erzincan", label: "Erzincan" },
        { id: "Erzurum", label: "Erzurum" },
        { id: "Eskisehir", label: "Eskisehir" },
        { id: "Gaziantep", label: "Gaziantep" },
        { id: "Giresun", label: "Giresun" },
        { id: "Gumushane", label: "Gumushane" },
        { id: "Hakkari", label: "Hakkari" },
        { id: "Hatay", label: "Hatay" },
        { id: "Isparta", label: "Isparta" },
        { id: "Mersin", label: "Mersin" },
        { id: "Istanbul", label: "Istanbul" },
        { id: "Izmir", label: "Izmir" },
        { id: "Kars", label: "Kars" },
        { id: "Kastamonu", label: "Kastamonu" },
        { id: "Kayseri", label: "Kayseri" },
        { id: "Kirklareli", label: "Kirklareli" },
        { id: "Kocaeli", label: "Kocaeli" },
        { id: "Konya", label: "Konya" },
        { id: "Kutahya", label: "Kutahya" },
        { id: "Malatya", label: "Malatya" },
        { id: "Manisa", label: "Manisa" },
        { id: "Kahramanmaras", label: "Kahramanmaras" },
        { id: "Mardin", label: "Mardin" },
        { id: "Mugla", label: "Mugla" },
        { id: "Mus", label: "Mus" },
        { id: "Nevsehir", label: "Nevsehir" },
        { id: "Nigde", label: "Nigde" },
        { id: "Ordu", label: "Ordu" },
        { id: "Rize", label: "Rize" },
        { id: "Sakarya", label: "Sakarya" },
        { id: "Samsun", label: "Samsun" },
        { id: "Siirt", label: "Siirt" },
        { id: "Sinop", label: "Sinop" },
        { id: "Sivas", label: "Sivas" },
        { id: "Tekirdag", label: "Tekirdag" },
        { id: "Tokat", label: "Tokat" },
        { id: "Trabzon", label: "Trabzon" },
        { id: "Tunceli", label: "Tunceli" },
        { id: "Sanliurfa", label: "Sanliurfa" },
        { id: "Usak", label: "Usak" },
        { id: "Van", label: "Van" },
        { id: "Yozgat", label: "Yozgat" },
         { id: "Zonguldak", label: "Zonguldak" },
        { id: "Bayburt", label: "Bayburt" },
        { id: "Karaman", label: "Karaman" },
        { id: "Kirikkale", label: "Kirikkale" },
        { id: "Batman", label: "Batman" },
        { id: "Sirnak", label: "Sirnak" },
        { id: "Bartin", label: "Bartin" },
        { id: "Artvin", label: "Artvin" },
        { id: "Aydin", label: "Aydin" },
        { id: "Ardahan", label: "Ardahan" },
        { id: "Igdir", label: "Igdir" },
        { id: "Yalova", label: "Yalova" },
        { id: "Karabuk", label: "Karabuk" },
        { id: "Kilis", label: "Kilis" },
        { id: "Osmaniye", label: "Osmaniye" },
        { id: "Duzce", label: "Duzce" }
    ];
    $scope.listesettings = { selectionLimit: 3, enableSearch: true };

    //tablo gösterimi için
    $scope.gizle = true;

    $scope.goster = function (sehir1, sehir2, sehir3) {

        //tablo gösterimi için
        $scope.gizle = true;

        console.log("1. sehir" + sehir1);
        console.log("2. sehir" + sehir2);
        console.log("3. sehir" + sehir3);
        //3 sehir kontrolü
        if (sehir1 && sehir2 && sehir3) {
            console.log("3 sehir girildi");

            //1-3 gün sınırı için
            $scope.gun1 = $filter('date')(new Date(), 'd'); // gun 01-31
            var sayac1 = 0;

            $scope.gun2 = $filter('date')(new Date(), 'd'); // gun 01-31
            var sayac2 = 0;

            $scope.gun3 = $filter('date')(new Date(), 'd'); // gun 01-31
            var sayac3 = 0;

            //tablo gösterimi için
            $scope.gizle = false;

            //sehir1
            $http.get("http://api.openweathermap.org/data/2.5/forecast?q=" + sehir1 + ",tr&appid=8e74a8fa923cf9bc7d0d57ddd146a0ac")
            .success(function (data) {
                console.log(sehir1 + " verileri alindi!!!");
                if (!data) {
                    return;
                    console.log("data gelmedi");
                };

                console.log("***" + data.city.name);

                $scope.degerler1 = [];

                for (var i = 0; i < 24; i++) {

                    var sicaklik = data.list[i].main.temp - 273;
                    sicaklik = Math.round(sicaklik)
                    console.log("sicaklik   :   " + sicaklik);

                    var zaman = data.list[i].dt_txt;

                    console.log("zaman   :   " + zaman);


                    //3 gunluk ayari
                    var zaman = data.list[i].dt_txt;

                    var mydate = new Date(zaman);
                    console.log(mydate.getDate());
                    var myday = mydate.getDate();

                    console.log("zaman   :   " + zaman);

                    if ($scope.gun1 == myday) {

                    } else {
                        $scope.gun1 = myday;
                        sayac1 = sayac1 + 1;
                        if (sayac1 == 3) {
                            return;
                        }
                    }


                    $scope.degerler1.push({
                        sicaklikDegeri: sicaklik,
                        zamanDegeri: zaman
                    });
                }

            })
            .error(function (error) {
                console.log(sehir1 + " verileri alinamadi");
            });

            //sehir2
            $http.get("http://api.openweathermap.org/data/2.5/forecast?q=" + sehir2 + ",tr&appid=8e74a8fa923cf9bc7d0d57ddd146a0ac")
            .success(function (data) {
                console.log(sehir2 + " verileri alindi!!!");
                if (!data) {
                    return;
                    console.log("data gelmedi");
                };

                console.log("***" + data.city.name);

                $scope.degerler2 = [];

                for (var i = 0; i < 24; i++) {

                    var sicaklik = data.list[i].main.temp - 273;
                    sicaklik = Math.round(sicaklik)
                    console.log("sicaklik   :   " + sicaklik);

                    var zaman = data.list[i].dt_txt;

                    console.log("zaman   :   " + zaman);

                    //3 gunluk ayari
                    var zaman = data.list[i].dt_txt;

                    var mydate = new Date(zaman);
                    console.log(mydate.getDate());
                    var myday = mydate.getDate();

                    console.log("zaman   :   " + zaman);

                    if ($scope.gun2 == myday) {

                    } else {
                        $scope.gun2 = myday;
                        sayac2 = sayac2 + 1;
                        if (sayac2 == 3) {
                            return;
                        }
                    }


                    $scope.degerler2.push({
                        sicaklikDegeri: sicaklik,
                        zamanDegeri: zaman
                    });
                }

            })
            .error(function (error) {
                console.log(sehir2 + " verileri alinamadi");
            });

            //degerler3
            $http.get("http://api.openweathermap.org/data/2.5/forecast?q=" + sehir3 + ",tr&appid=8e74a8fa923cf9bc7d0d57ddd146a0ac")
            .success(function (data) {
                console.log(sehir3 + " verileri alindi!!!");
                if (!data) {
                    return;
                    console.log("data gelmedi");
                };

                //console.log("***" + data.city.name);

                $scope.degerler3 = [];

                for (var i = 0; i < 24; i++) {

                    var sicaklik = data.list[i].main.temp - 273;
                    sicaklik = Math.round(sicaklik)
                    console.log("sicaklik   :   " + sicaklik);

                    var zaman = data.list[i].dt_txt;

                    console.log("zaman   :   " + zaman);

                    //3 gunluk ayari
                    var zaman = data.list[i].dt_txt;

                    var mydate = new Date(zaman);
                    console.log(mydate.getDate());
                    var myday = mydate.getDate();

                    console.log("zaman   :   " + zaman);

                    if ($scope.gun3 == myday) {

                    } else {
                        $scope.gun3 = myday;
                        sayac3 = sayac3 + 1;

                        if (sayac3 == 3) {
                            return;
                        }
                    }


                    $scope.degerler3.push({
                        sicaklikDegeri: sicaklik,
                        zamanDegeri: zaman
                    });
                }

            })
            .error(function (error) {
                console.log(sehir1 + " verileri alinamadi");
            });

        } else {
            console.log("3 den az sehir girildi");
            $scope.showAlert();
        }
       

    }

    //uyarı mesajı
    $scope.showAlert = function () {
        $ionicPopup.alert({
            title: 'Uyarı',
            template: '3 den az şehir girildi'
        });
    };

})



